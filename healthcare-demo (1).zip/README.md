# Healthcare Platform Demo

This is a simple demo project showing basic React frontend and Node.js backend setup.

## Technologies
- React
- Node.js
- Express

## How to run
- Frontend: Run `npm start` in the `frontend` folder  
- Backend: Run `node server.js` in the root folder
