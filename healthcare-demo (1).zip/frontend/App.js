import React from 'react';

function App() {
  return (
    <div>
      <h1>Healthcare Platform Demo</h1>
      <p>Welcome to the demo React app.</p>
    </div>
  );
}

export default App;
